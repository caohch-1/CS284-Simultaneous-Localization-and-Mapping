# Copyright (c) 2020 Jeff Irion and contributors

"""Graph SLAM solver in Python.

"""


__version__ = '0.0.7'
